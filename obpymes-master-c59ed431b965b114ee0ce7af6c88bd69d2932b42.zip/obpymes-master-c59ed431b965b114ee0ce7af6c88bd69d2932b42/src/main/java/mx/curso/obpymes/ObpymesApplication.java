package mx.curso.obpymes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObpymesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObpymesApplication.class, args);
	}
}
