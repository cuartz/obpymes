'use strict';

/**
 * @ngdoc function
 * @name angularEx2App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the angularEx2App
 */
angular.module('angularEx2App')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
