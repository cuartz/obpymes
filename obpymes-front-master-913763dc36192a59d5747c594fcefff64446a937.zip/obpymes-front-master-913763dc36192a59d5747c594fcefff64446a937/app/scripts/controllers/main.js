'use strict';

/**
 * @ngdoc function
 * @name angularEx2App.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the angularEx2App
 */
angular.module('angularEx2App')
  .controller('MainCtrl', function ($scope) {
    $scope.todos = [
      'Item1',
      'Item2',
      'Item3'
    ];
  });
